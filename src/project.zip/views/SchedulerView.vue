<template>
    <v-container class="fill-height d-flex align-center justify-center">
      <Stepper />
    </v-container>
  </template>
  
  <script setup>
  import Stepper from '@/components/Stepper.vue';
  </script>
  